/**
 * Clase principal del proyecto!
 * @author Carlos
 */
public class Clase02{
    /**
     * Punto de entrada del proyecto!
     * @param args argumentos de consola!
     */
    public static void main(String[] args) {
        System.out.println("Hola Mundo!!");

        // Comentarios de una sola linea
        // Este comentario no es visible al usuario final

        /*
            Bloque
            de
            Comentarios
            Este comentario no es visible al usuario final
         */

         //TODO tarea pendiente!! - Este comentario no es visible al usuario final

         /**
          * JAVA Doc
          *     Este comentario es visible al usuario final.
          *     Este comentario es visible por fuera del código binario
          *     Se debe colocar este comentario delante de la declaración 
          *     de método o clase
          */

        //C C++ Java C# Visual Basic Pascal typeScript, son lenguajes fuertemente tipados
        //PHP Python JavaScript, son lenguajes de tipado debil
        
        //Tipo de datos primitivo

        //Tipo de datos entero

        //Tipo de datos boolean         1 byte
        boolean bo=true;
        System.out.println(bo);
        bo=false;
        System.out.println(bo);

        /*
         *  1
         *  --------
         */

        //Tipo de datos byte        1 byte      (signed)
        byte by=100;
        System.out.println(by);

        /*
         * byte by=100;     //signed
         * 
         *  |-------|-------|
         *-128      0      127
         *
         * byteU by=100;    //unsigned
         * 
         *  |---------------|
         *  0              255
         */

    }
}